# Data

The dataset is **not** stored in this repository.

**Source:** [Breast Cancer Dataset (Royston & Altman) – Kaggle](https://www.kaggle.com/datasets/utkarshx27/breast-cancer-dataset-used-royston-and-altman)
File used: `gbsg.csv` (686 patients, German Breast Cancer Study Group).

Two ways to get it:

1. **Automatic** – just run the notebook; it downloads the file with `kagglehub`.
2. **Manual** – download `gbsg.csv` from Kaggle and place it here as `data/gbsg.csv`.
